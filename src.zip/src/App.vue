<template>
    <div id="app">
        <img alt="Vue logo" src="./assets/logo.png">
        <HelloWorld msg="Welcome to Your Vue.js App"/>
        <!-- <user-profile></user-profile> -->
        <profile :user="user"></profile>
        <profile-form :user="user" @save-user='showForm = false' @cancel=''></profile-form>

    </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import Profile from './components/User/Profile.vue'


export default {
    name: 'app',
    components: {
        HelloWorld, Profile
    },
    data() {
        return {
            user: {
                name: "Jonh",
                surname: 'Doe'
                }
            };
            // showForm: false    
        }
          
}

</script>

<style>
#app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
}
</style>
