<template>
    <div id="user-profile">
        <h1>User profile</h1>
        <p><strong>Name</strong> {{ user.name }}</p>
        <p><strong>Surname</strong> {{ user.surname }}</p>
        
        <div v-if="!showForm">
            <button @click="showForm = true">Edit</button>
        </div>
        <div v-else>
            <profile-form :user="user" @save-user='showForm = false' @cancel=''></profile-form>
        </div>
    </div>
</template>

<script>

export default {
  name: 'Profile',
  props: {
    user: {
            type: Object,
            required: true
        }
    },

    data() {
        return {
         
        }
    },
    methods: {
        saveUser() {
            this.$emit('save-user', user)
        }
    }
    
}

</script>

<style>

</style>
