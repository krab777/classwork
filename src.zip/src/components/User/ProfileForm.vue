<template>
    <div id="profile-form">
        
        <div>
            <label for="name"></label>
            <input type="text" id="name" v-model="user.name">
        </div> 

        <div>
            <label for="surname"></label>
            <input type="text" id="surname" v-model="user.surname">
        </div> 

        <div>
            <button @click="save">Save</button>
            <button @click="cancel">Cancel</button>
        </div>
        
        <div>
            
        </div>    
    
    </div>
</template>

<script>

import Profile from './components/User/Profile.vue'

export default {
  name: 'ProfileForm',
  props: {
    user: {
            type: Object,
            required: true
        }
    },

    components: {
        Profile
    },

    data() {
        return {
            user: {
                name: '',
                surname: ''
            }
        }
    },
    methods: {
        save(){
            let name = this.name
            let surname = this.surname

            this.$emit('save-user', (name, surname))
            this.cancel()
        },
        cancel(){
            this.$emit('cancel')
        }
    },
    created() {
        this.name = this.user.name
        this.surname = this.user.surname 
    }
}

</script>

<style>

</style>
